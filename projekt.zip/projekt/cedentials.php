<?php
return [
'username' => 'admin', 'nauczyciel', 'uczen', 'michał', 'adam'
'password_hash' => '$2y$10$Bmt8.pClv9TEhzItGN5h/./qNpVATkMqF92wH4ECSioOLO3IaZ4/2','$2y$10$U8UZZU6fpYiOuD1QMs7IausWzfzwTemKLaFvS/1ZUEASDdXMVx5nq','$2y$10$0AhPLKZk2DC/NZBgkCMhauGL5ksewlYhWXPoL1.kcWIaOf/7qVsUi', '$2y$10$t7dak8vWgyIzBvnuK3BuE.4TuRKZRGor.NgM4r1B7VUQAfvbYnqkK','$2y$10$Lq9shl64orevdMSyrV9OoO.7/iG/WvLgbChO1J6NPlCmF6FtVxPGG'


];