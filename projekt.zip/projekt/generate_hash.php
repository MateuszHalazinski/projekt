<?php
/*echo password_hash('admin', PASSWORD_DEFAULT);

echo password_hash('nauczyciel', PASSWORD_DEFAULT);

echo password_hash('uczen', PASSWORD_DEFAULT);

echo password_hash('michał', PASSWORD_DEFAULT);*/

echo password_hash('adam', PASSWORD_DEFAULT);

